var americaColor = '#ff002b',
  europeColor = '#002bff';
var backgroundColor = 'rgba(255, 255, 255, 0.0)';
var flagArry = {
  Portugal: 'flag pt',
  Wales: 'flag _Wales',
  Germany: 'flag de',
  Argentina: 'flag ar',
  Uruguay: 'flag uy',
  Columbia: 'flag co'
};

//Host polls: Read and send the polls to the server
var arrayUpdated = [];
