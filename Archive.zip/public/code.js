let americaColor = '#d00',
  europeColor = '#0272a4',
  backgroundColor = '#fff',
  flagArry = {
    Portugal: 'flag pt',
    Wales: 'flag _Wales',
    Germany: 'flag de',
    Argentina: 'flag ar',
    Uruguay: 'flag uy',
    Columbia: 'flag co'
  };
